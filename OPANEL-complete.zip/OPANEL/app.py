import logging, os
from flask import Flask, render_template, jsonify, session, redirect
from flask_socketio import SocketIO
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from database import db
from config import Config, LOG_DIR
from api.routes import api
from services.security import ensure_secret
from services.extensions import load_extensions

def create_app():
    ensure_secret(); app=Flask(__name__); app.config.from_object(Config); db.init_app(app)
    limiter=Limiter(key_func=get_remote_address,default_limits=["300 per minute"]); limiter.init_app(app)
    socketio=SocketIO(app,cors_allowed_origins="*",async_mode="threading")
    app.register_blueprint(api)
    @app.errorhandler(404)
    def e404(e):
        if __import__('flask').request.path.startswith('/api/'): return jsonify(error='Not found'),404
        return render_template('error.html',code=404,message='Page not found'),404
    @app.errorhandler(403)
    def e403(e): return render_template('error.html',code=403,message='Access denied'),403
    @app.errorhandler(500)
    def e500(e):
        app.logger.exception('Unhandled error')
        if __import__('flask').request.path.startswith('/api/'): return jsonify(error='Internal server error'),500
        return render_template('error.html',code=500,message='Internal server error'),500
    log=logging.FileHandler(LOG_DIR/'opanel.log');log.setLevel(logging.INFO);app.logger.addHandler(log)
    with app.app_context():
        db.create_all()
        from models import User,Node
        if User.query.count()==0: app.logger.info('No admin exists; run install.sh setup or create via /setup')
    load_extensions(app)
    return app,socketio
app,socketio=create_app()
@app.get('/')
def home():
    return render_template('index.html') if session.get('uid') else redirect('/login')
@app.get('/login')
def login_page(): return render_template('login.html')
@app.get('/setup')
def setup(): return render_template('setup.html')
if __name__=='__main__': socketio.run(app,host='0.0.0.0',port=Config.OPANEL_PORT,allow_unsafe_werkzeug=True)
