import os, secrets, shutil
from pathlib import Path
from flask import Blueprint,request,jsonify,session,send_file
from models import User,Server,Node,Activity
from database import db
from services.minecraft import manager
from services.system import stats
from services.security import safe_path,hash_token,verify_token
from services.backups import create as create_backup,restore
from config import SERVER_DIR,BACKUP_DIR

api=Blueprint("api",__name__,url_prefix="/api")
def user(): return db.session.get(User,session.get("uid")) if session.get("uid") else None
def auth(role=None):
    u=user()
    if not u or not u.enabled or (role and u.role!=role): return None
    return u
def owns(s,u): return u and (u.role=="admin" or s.owner_id==u.id)
def err(msg,code=400): return jsonify(error=msg),code

@api.post("/auth/login")
def login():
    b=request.get_json(silent=True) or {}; u=User.query.filter((User.username==b.get("username"))|(User.email==b.get("username"))).first()
    if not u or not u.enabled or not u.check_password(b.get("password", "")): return err("Invalid credentials",401)
    session.clear();session["uid"]=u.id;return jsonify(ok=True,user={"username":u.username,"role":u.role})
@api.post("/auth/logout")
def logout(): session.clear();return jsonify(ok=True)
@api.post("/auth/register")
def register():
    b=request.get_json(silent=True) or {}; username=(b.get("username") or "").strip();email=(b.get("email") or "").strip();pw=b.get("password") or ""
    if len(username)<3 or len(pw)<8 or "@" not in email:return err("Invalid registration data")
    if User.query.filter((User.username==username)|(User.email==email)).first():return err("Username or email already exists",409)
    u=User(username=username,email=email,role="admin" if User.query.count()==0 else "user");u.set_password(pw);db.session.add(u);db.session.commit();return jsonify(ok=True),201

@api.get("/system/stats")
def system():
    if not auth():return err("Unauthorized",401)
    return jsonify(stats())
@api.get("/servers")
def get_servers():
    u=auth();
    if not u:return err("Unauthorized",401)
    q=Server.query.all() if u.role=="admin" else Server.query.filter_by(owner_id=u.id).all()
    return jsonify([server_json(s) for s in q])
def server_json(s):return {"id":s.id,"name":s.name,"description":s.description,"port":s.port,"memory_mb":s.memory_mb,"cpu_percent":s.cpu_percent,"disk_mb":s.disk_mb,"software":s.software,"version":s.version,"status":manager.status(s.id),"node":s.node.name if s.node else None}

@api.post("/servers")
def create_server():
    u=auth();
    if not u:return err("Unauthorized",401)
    b=request.get_json(silent=True) or {}; name=(b.get("name") or "Minecraft").strip();port=int(b.get("port",25565));node_id=int(b.get("node_id") or 0)
    node=db.session.get(Node,node_id) if node_id else Node.query.first()
    if not node:return err("No node available")
    if Server.query.filter_by(node_id=node.id,port=port).first():return err("Port already allocated",409)
    if not 1024<=port<=65535:return err("Invalid port")
    s=Server(id=secrets.token_hex(10),name=name,owner_id=u.id,node_id=node.id,port=port,memory_mb=int(b.get("memory_mb",2048)),disk_mb=int(b.get("disk_mb",20480)))
    db.session.add(s);db.session.add(Activity(message=f"Server created: {name}"));db.session.commit();return jsonify(server_json(s)),201

def get_server(sid):
    s=db.session.get(Server,sid);u=auth()
    if not s:return None,None
    return s,u
@api.post("/servers/<sid>/start")
def start_server(sid):
    s,u=get_server(sid)
    if not s or not owns(s,u):return err("Not found",404)
    try:manager.start(s);return jsonify(ok=True)
    except Exception as e:return err(str(e))
@api.post("/servers/<sid>/stop")
def stop_server(sid):
    s,u=get_server(sid)
    if not s or not owns(s,u):return err("Not found",404)
    manager.stop(sid);return jsonify(ok=True)
@api.post("/servers/<sid>/restart")
def restart_server(sid):
    s,u=get_server(sid)
    if not s or not owns(s,u):return err("Not found",404)
    manager.stop(sid);import time;time.sleep(1)
    try:manager.start(s);return jsonify(ok=True)
    except Exception as e:return err(str(e))
@api.post("/servers/<sid>/kill")
def kill_server(sid):
    s,u=get_server(sid)
    if not s or not owns(s,u):return err("Not found",404)
    manager.stop(sid,True);return jsonify(ok=True)
@api.get("/servers/<sid>/console")
def get_console(sid):
    s,u=get_server(sid)
    if not s or not owns(s,u):return err("Not found",404)
    return jsonify(log=manager.console(sid))
@api.post("/servers/<sid>/command")
def command(sid):
    s,u=get_server(sid)
    if not s or not owns(s,u):return err("Not found",404)
    try:manager.command(sid,(request.get_json(silent=True) or {}).get("command", ""));return jsonify(ok=True)
    except Exception as e:return err(str(e))

@api.get("/servers/<sid>/files")
def files(sid):
    s,u=get_server(sid)
    if not s or not owns(s,u):return err("Not found",404)
    try:
        p=safe_path(SERVER_DIR/sid,request.args.get("path",""));
        return jsonify([{"name":x.name,"directory":x.is_dir(),"size":x.stat().st_size,"mtime":x.stat().st_mtime} for x in p.iterdir()])
    except Exception as e:return err(str(e))
@api.post("/servers/<sid>/files")
def file_action(sid):
    s,u=get_server(sid)
    if not s or not owns(s,u):return err("Not found",404)
    b=request.get_json(silent=True) or {};action=b.get("action");rel=b.get("path","")
    try:
        p=safe_path(SERVER_DIR/sid,rel)
        if action=="mkdir":p.mkdir(parents=False);return jsonify(ok=True)
        if action=="write":p.write_text(b.get("content","") ,encoding="utf-8");return jsonify(ok=True)
        if action=="rename":p.rename(safe_path(SERVER_DIR/sid,b["new_path"]));return jsonify(ok=True)
        if action=="delete":shutil.rmtree(p) if p.is_dir() else p.unlink();return jsonify(ok=True)
        if action=="read":return jsonify(content=p.read_text(encoding="utf-8"))
        return err("Unknown file action")
    except Exception as e:return err(str(e))

@api.get("/nodes")
def nodes():
    u=auth("admin");
    if not u:return err("Forbidden",403)
    return jsonify([{"id":n.id,"name":n.name,"host":n.host,"port":n.port,"location":n.location,"last_seen":n.last_seen.isoformat() if n.last_seen else None} for n in Node.query.all()])
@api.post("/nodes")
def add_node():
    u=auth("admin");
    if not u:return err("Forbidden",403)
    b=request.get_json(silent=True) or {};token=secrets.token_urlsafe(32);n=Node(name=b.get("name","Node"),host=b.get("host","127.0.0.1"),port=int(b.get("port",9001)),location=b.get("location",""),token_hash=hash_token(token),memory_mb=int(b.get("memory_mb",0)),disk_mb=int(b.get("disk_mb",0)),cpu_cores=int(b.get("cpu_cores",1)))
    db.session.add(n);db.session.commit();return jsonify(node={"id":n.id,"name":n.name},token=token),201

@api.post("/servers/<sid>/install")
def install(sid):
    s,u=get_server(sid)
    if not s or not owns(s,u):return err("Not found",404)
    b=request.get_json(silent=True) or {};software=b.get("software","paper");version=b.get("version","")
    if not version:return err("Version required")
    try:manager.install(sid,software,version);s.software=software;s.version=version;db.session.commit();return jsonify(ok=True)
    except Exception as e:return err(str(e),502)
@api.get("/minecraft/versions")
def mc_versions():
    u=auth();
    if not u:return err("Unauthorized",401)
    try:return jsonify(versions=manager.versions())
    except Exception as e:return err(str(e),502)
@api.post("/servers/<sid>/backup")
def backup(sid):
    s,u=get_server(sid)
    if not s or not owns(s,u):return err("Not found",404)
    try:p=create_backup(sid);return jsonify(file=p.name)
    except Exception as e:return err(str(e))
