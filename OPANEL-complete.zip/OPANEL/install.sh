#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ "$(id -u)" -eq 0 ]; then APT=sudo; else APT=sudo; fi
if command -v apt-get >/dev/null; then $APT apt-get update; $APT apt-get install -y python3 python3-venv python3-pip curl git unzip openjdk-21-jre-headless; fi
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
mkdir -p data/servers data/backups logs extensions themes
chmod +x start.sh update.sh uninstall.sh
python3 - <<'PY'
from config import SECRET_FILE
from services.security import ensure_secret
ensure_secret()
from app import app
from database import db
with app.app_context(): db.create_all()
print('Database initialized.')
PY
read -r -p 'Admin username: ' U
read -r -p 'Admin email: ' E
read -r -s -p 'Admin password (8+ chars): ' P; echo
python3 - "$U" "$E" "$P" <<'PY'
import sys
from app import app
from database import db
from models import User
u,e,p=sys.argv[1:]
with app.app_context():
    if User.query.count()==0:
        x=User(username=u,email=e,role='admin');x.set_password(p);db.session.add(x);db.session.commit();print('Admin created.')
    else: print('Users already exist; admin creation skipped.')
PY
read -r -p 'Panel port [3000]: ' PORT
PORT=${PORT:-3000}
printf 'OPANEL_PORT=%s\n' "$PORT" > .env
cat > opanel-startup.sh <<'EOS'
#!/usr/bin/env bash
cd "$(dirname "$0")"
exec ./start.sh
EOS
chmod +x opanel-startup.sh
echo "Install complete. Run ./start.sh"
echo "Panel: http://YOUR_VPS_IP:$PORT"
