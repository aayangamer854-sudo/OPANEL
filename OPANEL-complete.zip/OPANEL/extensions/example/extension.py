def register(app):
    @app.get('/extension/example/health')
    def extension_health(): return {'extension':'example','ok':True}
