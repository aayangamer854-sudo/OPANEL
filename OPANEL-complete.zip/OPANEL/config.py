import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
SERVER_DIR = DATA_DIR / "servers"
BACKUP_DIR = DATA_DIR / "backups"
LOG_DIR = BASE_DIR / "logs"
DB_PATH = DATA_DIR / "opanel.db"
SECRET_FILE = DATA_DIR / ".secret_key"

for p in (DATA_DIR, SERVER_DIR, BACKUP_DIR, LOG_DIR): p.mkdir(parents=True, exist_ok=True)

class Config:
    SECRET_KEY = os.getenv("OPANEL_SECRET_KEY") or SECRET_FILE.read_text().strip() if SECRET_FILE.exists() else os.urandom(32).hex()
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", f"sqlite:///{DB_PATH}")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.getenv("OPANEL_SECURE_COOKIE", "0") == "1"
    MAX_CONTENT_LENGTH = 2 * 1024 * 1024 * 1024
    OPANEL_PORT = int(os.getenv("OPANEL_PORT", "3000"))
