import psutil

def stats():
    m=psutil.virtual_memory(); d=psutil.disk_usage("/"); net=psutil.net_io_counters()
    return {"cpu":psutil.cpu_percent(0.1),"ram_used":m.used,"ram_total":m.total,"disk_used":d.used,"disk_total":d.total,"rx":net.bytes_recv,"tx":net.bytes_sent}
