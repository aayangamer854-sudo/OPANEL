import json, importlib.util
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent/"extensions"
def load_extensions(app):
    BASE.mkdir(exist_ok=True)
    for d in BASE.iterdir():
        if not d.is_dir(): continue
        mf=d/"manifest.json"; py=d/"extension.py"
        try:
            if not mf.exists() or not py.exists(): continue
            manifest=json.loads(mf.read_text()); name=manifest.get("name",d.name)
            if not name.replace("-","").replace("_","").isalnum(): continue
            spec=importlib.util.spec_from_file_location(f"opanel_ext_{d.name}",py); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            if hasattr(mod,"register"): mod.register(app)
        except Exception as e: app.logger.error("Extension %s failed: %s",d.name,e)
