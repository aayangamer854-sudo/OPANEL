import json, re, subprocess, threading, time
from pathlib import Path
import requests
from services.security import safe_path
from config import SERVER_DIR

MIN_VERSION=(1,16,0)

class MinecraftManager:
    def __init__(self): self.procs={}; self.logs={}; self.lock=threading.RLock()
    def folder(self,sid): return SERVER_DIR/sid
    def versions(self):
        r=requests.get("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json",timeout=15); r.raise_for_status()
        out=[]
        for v in r.json()["versions"]:
            if v["type"] not in ("release",): continue
            m=re.match(r"^(\d+)\.(\d+)(?:\.(\d+))?$",v["id"])
            if m and tuple(map(lambda x:int(x or 0),m.groups())) >= MIN_VERSION: out.append(v["id"])
        return out
    def install(self,sid,software,version):
        folder=self.folder(sid); folder.mkdir(parents=True,exist_ok=True); software=software.lower()
        if software=="vanilla": url=self._vanilla_url(version)
        elif software=="paper": url=self._paper_url(version)
        elif software=="purpur": url=self._purpur_url(version)
        elif software=="fabric": url=self._fabric_url(version)
        else: raise ValueError("Forge installer is not supported by this build; use Vanilla, Paper, Purpur or Fabric.")
        tmp=folder/"server.jar.part"; dest=folder/"server.jar"
        with requests.get(url,stream=True,timeout=30) as r:
            r.raise_for_status()
            with open(tmp,"wb") as f:
                for chunk in r.iter_content(1024*1024):
                    if chunk:f.write(chunk)
        if tmp.stat().st_size < 100000: tmp.unlink(missing_ok=True); raise ValueError("Downloaded file was unexpectedly small")
        tmp.replace(dest); return str(dest)
    def _vanilla_url(self,v):
        m=requests.get("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json",timeout=15).json()
        x=next((x for x in m["versions"] if x["id"]==v),None)
        if not x: raise ValueError("Unsupported Minecraft version")
        meta=requests.get(x["url"],timeout=15).json(); return meta["downloads"]["server"]["url"]
    def _paper_url(self,v):
        j=requests.get(f"https://api.papermc.io/v2/projects/paper/versions/{v}",timeout=15); j.raise_for_status(); b=j.json()["builds"][-1]
        return f"https://api.papermc.io/v2/projects/paper/versions/{v}/builds/{b}/downloads/paper-{v}-{b}.jar"
    def _purpur_url(self,v):
        j=requests.get(f"https://api.purpurmc.org/v2/purpur/{v}",timeout=15); j.raise_for_status(); b=j.json()["builds"]["latest"]
        return f"https://api.purpurmc.org/v2/purpur/{v}/{b}/download"
    def _fabric_url(self,v):
        j=requests.get(f"https://meta.fabricmc.net/v2/versions/loader/{v}",timeout=15); j.raise_for_status(); x=j.json()[0]
        loader=x["loader"]["version"]; installer=requests.get("https://meta.fabricmc.net/v2/versions/installer",timeout=15).json()[0]["version"]
        return f"https://meta.fabricmc.net/v2/versions/loader/{v}/{loader}/{installer}/server/jar"
    def status(self,sid):
        p=self.procs.get(sid); return "running" if p and p.poll() is None else "stopped"
    def start(self,server):
        sid=server.id
        if self.status(sid)=="running": return
        folder=self.folder(sid); jar=folder/server.jar
        if not jar.exists(): raise ValueError("Install a Minecraft server JAR first")
        env=json.loads(server.environment or "{}"); import os
        e=os.environ.copy(); e.update({str(k):str(v) for k,v in env.items()})
        cmd=server.startup_command.replace("{memory}",str(server.memory_mb)).split()
        log=folder/"console.log"; f=open(log,"a",buffering=1)
        p=subprocess.Popen(cmd,cwd=folder,stdin=subprocess.PIPE,stdout=f,stderr=subprocess.STDOUT,text=True,env=e,start_new_session=True)
        self.procs[sid]=(p,f); threading.Thread(target=self._watch,args=(sid,),daemon=True).start()
    def _watch(self,sid):
        while True:
            p=self.procs.get(sid)
            if not p:return
            if p[0].poll() is not None:
                p[1].close(); return
            time.sleep(1)
    def stop(self,sid,force=False):
        p=self.procs.get(sid)
        if not p or p[0].poll() is not None:return
        if force:p[0].kill()
        else:
            p[0].stdin.write("stop\n");p[0].stdin.flush()
    def command(self,sid,cmd):
        p=self.procs.get(sid)
        if not p or p[0].poll() is not None:raise ValueError("Server is not running")
        if not cmd or "\x00" in cmd:raise ValueError("Invalid command")
        p[0].stdin.write(cmd+"\n");p[0].stdin.flush()
    def console(self,sid):
        p=self.folder(sid)/"console.log"; return p.read_text(errors="replace")[-50000:] if p.exists() else ""

manager=MinecraftManager()
