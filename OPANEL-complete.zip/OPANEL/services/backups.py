import tarfile, time
from pathlib import Path
from config import SERVER_DIR,BACKUP_DIR
from services.security import safe_path

def create(sid):
    src=safe_path(SERVER_DIR,sid); BACKUP_DIR.mkdir(parents=True,exist_ok=True)
    name=f"{sid}-{int(time.time())}.tar.gz"; dest=BACKUP_DIR/name
    with tarfile.open(dest,"w:gz") as t: t.add(src,arcname=sid)
    return dest

def restore(backup,sid):
    src=safe_path(BACKUP_DIR,backup); dest=safe_path(SERVER_DIR,sid)
    if not src.exists(): raise ValueError("Backup not found")
    with tarfile.open(src,"r:gz") as t:
        for m in t.getmembers():
            target=safe_path(SERVER_DIR,m.name)
            t.extract(m,SERVER_DIR)
    return True
