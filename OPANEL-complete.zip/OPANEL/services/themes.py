import json
from pathlib import Path
THEMES=Path(__file__).resolve().parent.parent/"themes"
def get_themes():
    out=[]
    for d in THEMES.iterdir():
        if d.is_dir() and (d/"theme.json").exists():
            try: out.append(json.loads((d/"theme.json").read_text()))
            except: pass
    return out
