import secrets
from pathlib import Path
from werkzeug.security import generate_password_hash, check_password_hash
from config import SECRET_FILE

def ensure_secret():
    if not SECRET_FILE.exists():
        SECRET_FILE.write_text(secrets.token_hex(32)); SECRET_FILE.chmod(0o600)

def hash_token(x): return generate_password_hash(x)
def verify_token(h,x): return check_password_hash(h,x)

def safe_path(root, relative=""):
    root=Path(root).resolve(); target=(root/relative).resolve()
    if target != root and root not in target.parents: raise ValueError("Path outside server directory")
    return target
