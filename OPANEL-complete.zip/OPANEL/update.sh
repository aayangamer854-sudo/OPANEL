#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ -d .venv ] || { echo 'Run install.sh first'; exit 1; }
. .venv/bin/activate
python -m pip install -r requirements.txt
python3 - <<'PY'
from app import app
from database import db
with app.app_context(): db.create_all()
PY
echo 'OPANEL updated.'
