import os, secrets, subprocess, threading, time
from flask import Flask,request,jsonify
import psutil
app=Flask(__name__);TOKEN=os.getenv("OPANEL_NODE_TOKEN","")
def ok(): return secrets.compare_digest(request.headers.get("Authorization","").removeprefix("Bearer "),TOKEN)
@app.before_request
def guard():
    if request.path!="/health" and not ok():return jsonify(error="Unauthorized"),401
@app.get("/health")
def health():return jsonify(ok=True)
@app.get("/stats")
def stats():
    m=psutil.virtual_memory();d=psutil.disk_usage("/");return jsonify(cpu=psutil.cpu_percent(.1),ram_used=m.used,ram_total=m.total,disk_used=d.used,disk_total=d.total)
if __name__=="__main__":app.run(host="0.0.0.0",port=int(os.getenv("OPANEL_NODE_PORT","9001")))
