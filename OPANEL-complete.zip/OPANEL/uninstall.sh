#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
./stop.sh 2>/dev/null || true
rm -rf .venv
rm -f opanel-startup.sh
printf 'OPANEL runtime removed. Database and server data were kept.\n'
