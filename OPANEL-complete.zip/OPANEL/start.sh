#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
. .venv/bin/activate
if [ -f .env ]; then set -a; . ./.env; set +a; fi
exec python3 app.py
