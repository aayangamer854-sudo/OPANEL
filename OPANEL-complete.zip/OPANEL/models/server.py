from datetime import datetime, timezone
from database import db
class Server(db.Model):
    id=db.Column(db.String(32),primary_key=True); name=db.Column(db.String(100),nullable=False)
    description=db.Column(db.Text,default=""); owner_id=db.Column(db.Integer,db.ForeignKey("user.id"),nullable=False)
    node_id=db.Column(db.Integer,db.ForeignKey("node.id"),nullable=False); port=db.Column(db.Integer,nullable=False)
    memory_mb=db.Column(db.Integer,default=2048); cpu_percent=db.Column(db.Float,default=100); disk_mb=db.Column(db.Integer,default=20480)
    jar=db.Column(db.String(255),default="server.jar"); software=db.Column(db.String(30),default="paper"); version=db.Column(db.String(30),default="")
    startup_command=db.Column(db.String(1000),default="java -Xms{memory}M -Xmx{memory}M -jar server.jar nogui")
    environment=db.Column(db.Text,default="{}"); created_at=db.Column(db.DateTime,default=lambda:datetime.now(timezone.utc))
    owner=db.relationship("User",backref="servers"); node=db.relationship("Node",backref="servers")
