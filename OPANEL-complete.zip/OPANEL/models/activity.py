from datetime import datetime, timezone
from database import db
class Activity(db.Model):
    id=db.Column(db.Integer,primary_key=True); message=db.Column(db.String(255),nullable=False)
    created_at=db.Column(db.DateTime,default=lambda:datetime.now(timezone.utc))
