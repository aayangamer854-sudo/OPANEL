from datetime import datetime, timezone
from werkzeug.security import generate_password_hash, check_password_hash
from database import db

class User(db.Model):
    id=db.Column(db.Integer,primary_key=True); username=db.Column(db.String(80),unique=True,nullable=False)
    email=db.Column(db.String(255),unique=True,nullable=False); password_hash=db.Column(db.String(255),nullable=False)
    role=db.Column(db.String(20),default="user",nullable=False); enabled=db.Column(db.Boolean,default=True)
    created_at=db.Column(db.DateTime,default=lambda:datetime.now(timezone.utc))
    def set_password(self,p): self.password_hash=generate_password_hash(p)
    def check_password(self,p): return check_password_hash(self.password_hash,p)
