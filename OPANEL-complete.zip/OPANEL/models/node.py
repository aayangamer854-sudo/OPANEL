from datetime import datetime, timezone
from database import db
class Node(db.Model):
    id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(100),nullable=False); host=db.Column(db.String(255),nullable=False)
    port=db.Column(db.Integer,default=9001); location=db.Column(db.String(100),default=""); memory_mb=db.Column(db.Integer,default=0)
    disk_mb=db.Column(db.Integer,default=0); cpu_cores=db.Column(db.Integer,default=1); token_hash=db.Column(db.String(255),nullable=False)
    last_seen=db.Column(db.DateTime); enabled=db.Column(db.Boolean,default=True)
    def heartbeat(self): self.last_seen=datetime.now(timezone.utc)
