# OPANEL

OPANEL is an independently implemented Minecraft hosting control-panel foundation for Linux VPS environments. It does not use or copy proprietary JTG assets or source.

## Included
- Flask + SQLAlchemy + SQLite
- Session authentication and first-user admin setup
- Native Java process management
- Real console log capture and commands
- Server ownership and port collision checks
- Safe server-directory file listing/actions
- CPU/RAM/disk/network monitoring
- Minecraft version discovery from Mojang's public manifest
- Automatic Vanilla/Paper/Purpur/Fabric JAR installation
- Extension loader and theme directory
- Lightweight node-agent stats/health service
- Backup archive creation service
- Mobile-responsive UI
- No Docker or systemd requirement

## Install
```bash
chmod +x *.sh
./install.sh
./start.sh
```
Then open `http://VPS_IP:3000` (or your selected port).

## Minecraft installer
The API endpoint `GET /api/minecraft/versions` discovers release versions from Mojang and filters from 1.16 onward. Server installation is `POST /api/servers/<id>/install` with `software` = `vanilla`, `paper`, `purpur`, or `fabric` and a discovered `version`.

Forge is intentionally not silently substituted: Forge uses version-specific installers and is not included in this baseline until its installer metadata is validated.

## Node agent
On a separate Linux node:
```bash
cd nodes
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
export OPANEL_NODE_TOKEN='your-node-token'
export OPANEL_NODE_PORT=9001
python3 agent.py
```

The current agent provides authenticated health/stat endpoints. A full remote job protocol should be deployed only after TLS, replay protection, node enrollment, and per-server process supervision are configured.

## Production note
This repository is a runnable foundation, not a claim of complete enterprise production readiness. Before exposing it publicly, put it behind HTTPS, configure secure cookies, restrict the node API by network/firewall, add a reverse proxy, and complete remote node job execution, uploads/downloads, scheduled backups, granular permissions, WebSocket authorization, and full installer progress tracking.
