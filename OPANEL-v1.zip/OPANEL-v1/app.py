import os,json,uuid,subprocess,shutil,time
from pathlib import Path
from flask import Flask,request,jsonify,render_template
import psutil
BASE=Path(__file__).resolve().parent
SERVERS=BASE/'data'/'servers'; SERVERS.mkdir(parents=True,exist_ok=True)
app=Flask(__name__,static_folder='static',template_folder='templates'); processes={}
def meta(sid):
 p=SERVERS/sid/'server.json'; return json.loads(p.read_text()) if p.exists() else None
def status(sid):
 p=processes.get(sid); return 'running' if p and p.poll() is None else 'stopped'
def docker_available(): return shutil.which('docker') is not None and Path('/var/run/docker.sock').exists()
@app.get('/')
def index(): return render_template('index.html')
@app.get('/api/system')
def system():
 m=psutil.virtual_memory(); d=psutil.disk_usage('/')
 return jsonify(cpu=psutil.cpu_percent(.1),ram_used=m.used,ram_total=m.total,disk_used=d.used,disk_total=d.total,docker=docker_available(),platform=os.uname().sysname,arch=os.uname().machine)
@app.get('/api/servers')
def servers():
 out=[]
 for p in SERVERS.iterdir():
  if p.is_dir():
   x=meta(p.name)
   if x: x['status']=status(p.name); out.append(x)
 return jsonify(out)
@app.post('/api/servers')
def create():
 b=request.get_json(silent=True) or {}; name=(b.get('name') or 'Minecraft').strip()[:80]
 try: port=int(b.get('port') or 25565)
 except: return jsonify(error='Invalid port'),400
 if not 1024<=port<=65535:return jsonify(error='Port must be 1024-65535'),400
 for p in SERVERS.iterdir():
  x=meta(p.name) if p.is_dir() else None
  if x and int(x.get('port',-1))==port:return jsonify(error='Port already in use'),409
 sid=uuid.uuid4().hex[:10]; folder=SERVERS/sid; folder.mkdir()
 x={'id':sid,'name':name,'port':port,'runtime':b.get('runtime','auto'),'jar':'server.jar','memory':b.get('memory','2G')}
 (folder/'server.json').write_text(json.dumps(x,indent=2)); (folder/'eula.txt').write_text('eula=true\n'); return jsonify(x),201
@app.post('/api/servers/<sid>/start')
def start(sid):
 x=meta(sid)
 if not x:return jsonify(error='Server not found'),404
 if status(sid)=='running':return jsonify(status='running')
 folder=SERVERS/sid; jar=folder/x['jar']
 if not jar.exists():return jsonify(error='server.jar not found'),400
 log=open(folder/'console.log','a',buffering=1); mem=x.get('memory','2G')
 try:p=subprocess.Popen(['java',f'-Xms{mem}',f'-Xmx{mem}','-jar',jar.name,'nogui'],cwd=folder,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,text=True)
 except FileNotFoundError:log.close();return jsonify(error='Java not found'),400
 processes[sid]=p; return jsonify(status='running')
@app.post('/api/servers/<sid>/stop')
def stop(sid):
 p=processes.get(sid)
 if p and p.poll() is None:
  try:p.stdin.write('stop\n');p.stdin.flush()
  except:p.terminate()
 return jsonify(status='stopping')
@app.post('/api/servers/<sid>/restart')
def restart(sid):
 p=processes.get(sid)
 if p and p.poll() is None:
  try:p.stdin.write('stop\n');p.stdin.flush();p.wait(20)
  except:
   try:p.kill()
   except:pass
 time.sleep(1); return start(sid)
@app.get('/api/servers/<sid>/console')
def console(sid):
 p=SERVERS/sid/'console.log'; return jsonify(log=p.read_text(errors='replace')[-30000:] if p.exists() else '')
@app.post('/api/servers/<sid>/command')
def command(sid):
 p=processes.get(sid)
 if not p or p.poll() is not None:return jsonify(error='Server is not running'),400
 cmd=((request.get_json(silent=True) or {}).get('command') or '').strip()
 if not cmd:return jsonify(error='Empty command'),400
 try:p.stdin.write(cmd+'\n');p.stdin.flush()
 except Exception as e:return jsonify(error=str(e)),500
 return jsonify(ok=True)
@app.delete('/api/servers/<sid>')
def delete(sid):
 p=processes.get(sid)
 if p and p.poll() is None:return jsonify(error='Stop the server first'),400
 folder=SERVERS/sid
 if not folder.exists():return jsonify(error='Server not found'),404
 shutil.rmtree(folder); processes.pop(sid,None); return jsonify(ok=True)
@app.get('/api/network')
def network():return jsonify(provider='Minekube Connect',status='integration-ready')
if __name__=='__main__':app.run(host='0.0.0.0',port=int(os.getenv('OPANEL_PORT','3000')))
