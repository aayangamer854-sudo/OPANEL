#!/usr/bin/env bash
./stop.sh || true
rm -rf .venv
echo 'OPANEL runtime removed; data kept.'
