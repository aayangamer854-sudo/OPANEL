#!/usr/bin/env bash
pkill -f 'python3 app.py' || true
