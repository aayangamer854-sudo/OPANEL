#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
. .venv/bin/activate
export OPANEL_PORT="${OPANEL_PORT:-3000}"
exec python3 app.py
