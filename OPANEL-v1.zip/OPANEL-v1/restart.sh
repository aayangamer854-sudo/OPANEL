#!/usr/bin/env bash
./stop.sh || true
sleep 1
./start.sh
