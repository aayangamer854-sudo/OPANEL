# OPANEL v1
Lightweight Minecraft hosting panel starter.

Features: native Java lifecycle, console, commands, CPU/RAM/disk monitoring, port collision detection, Docker detection hook, Minekube Connect integration placeholder, extension/theme directories, and no systemd dependency.

## Install
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip openjdk-21-jre-headless git
chmod +x *.sh
./install.sh
./start.sh
```
Open `http://YOUR_VPS_IP:3000`.

Put a Minecraft JAR at `data/servers/<server-id>/server.jar`.

This is a functional v1 starter, not a production replacement for Pterodactyl. Full auth, multi-node agents, Docker orchestration, uploads, backups and real Minekube client integration should be added before public hosting use.
