#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
mkdir -p data/servers extensions themes
chmod +x *.sh 2>/dev/null || true
echo 'OPANEL installed. Run ./start.sh'
